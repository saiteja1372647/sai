# Computer-Networks

Computer Networks course programs in C. 

The programs have been implemented using the BSD Sockets API and PCAP in C.

The repo contains implementations of various design paradigms of networked applications using TCP sockets, UDP sockets, raw sockets, Unix domain sockets and several Unix system IPC mechanisms.

Made with lots of blood, sweat, caffeine and </> for understanding networked applications.
