# Chatroom using TCP sockets

Implementation of a basic chatroom.
Each message can either be broadcasted to all clients or pinged to a particular client by name.

I still don't get why fgets() or scanf("%[^\n]s", ..) or scanf("%[^\n]%*c", ..) isn't working. So, I can send words only. Nothing great, but ok!!
