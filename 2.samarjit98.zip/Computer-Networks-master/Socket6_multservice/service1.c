#include <stdio.h>

int main(int argc, char** argv)
{
	printf("Service 1\n");
	return 0;
}