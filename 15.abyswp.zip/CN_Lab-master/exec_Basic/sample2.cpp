#include <bits/stdc++.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main(int argc, char *argv[])
{
	cout<<"Started2."<<endl;
	cout<<"I'm the child2"<<endl;

	return 0;
}