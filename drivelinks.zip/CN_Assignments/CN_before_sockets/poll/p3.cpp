#include <stdio.h> 
#include <unistd.h>
#include <sys/types.h>      
#include <sys/wait.h>
#include<bits/stdc++.h>
using namespace std;
#define e 1024
int main(){
    string str;
    getline(cin, str);
    cout<<str;
}
