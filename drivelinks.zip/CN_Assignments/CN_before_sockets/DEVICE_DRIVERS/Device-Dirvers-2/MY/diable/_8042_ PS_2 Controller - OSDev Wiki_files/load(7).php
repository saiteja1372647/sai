;mw.loader.state({"site":"ready"});

/* cache key: wikidb:resourceloader:filter:minify-js:4:7ae2d4bbda341e08f06179ae4946fe6c */
