jQuery(function($){var $pCactions=$('#p-cactions');$pCactions.find('h5 a').click(function(e){$pCactions.find('.menu').toggleClass('menuForceShow');e.preventDefault();}).focus(function(){$pCactions.addClass('vectorMenuFocus');}).blur(function(){$pCactions.removeClass('vectorMenuFocus');});});;mw.loader.state({"skins.vector":"ready"});

/* cache key: wikidb:resourceloader:filter:minify-js:4:26824a89365a40f4af7e018abc19d2da */
