#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"enter number:";
	cin>>n;
	cout<<"your entered "<<n<<endl;
}
