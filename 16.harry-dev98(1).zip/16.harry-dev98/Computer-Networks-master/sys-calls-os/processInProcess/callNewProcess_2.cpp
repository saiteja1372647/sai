#include <bits/stdc++.h>
using namespace std;

int main(){
    cout<<"in a new process from callNewProcess_1.cpp file\n";
    return 0;
}