#include <bits/stdc++.h>
using namespace std;

int main(){
    cin>>a>>b;
    return 0;
}