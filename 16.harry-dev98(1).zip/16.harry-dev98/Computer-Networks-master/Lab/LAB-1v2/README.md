### IMP System calls Used:
` poll() `
` getpgid() `
` killpg() `
` popen2_ForFdAndPid() `
` dup2 `
` execv `
` pipe() `
` mkfifo() `
` signal() `


### signals used
` SIGINT `
` SIGCONT `
` SIGSTOP `
` SIGUSR1 `
` SIGUSR2 `