#include<bits/stdc++.h>
using namespace std;

int main(){
	cout<<"FromP2\n";
	return 0;
}
