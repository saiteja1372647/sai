#include<bits/stdc++.h>
using namespace std;

int main(){
	string s;
	cin>>s;
	s+=" FromP2";
	cout<<s;
	return 0;
}
