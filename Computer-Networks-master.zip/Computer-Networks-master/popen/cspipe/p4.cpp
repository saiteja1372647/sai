#include<bits/stdc++.h>
using namespace std;

int main(){
	string s;
	cin>>s;
	s+="FromP4";
	cout<<s<<"\n";
	return 0;
}
