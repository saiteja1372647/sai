#include<bits/stdc++.h>
using namespace std;

int main(){
	string s;
	cin>>s;
	s+="FromP3";
	cout<<s<<"\n";
	return 0;
}
