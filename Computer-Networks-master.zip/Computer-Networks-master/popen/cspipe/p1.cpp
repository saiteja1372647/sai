#include<bits/stdc++.h>
#include<fcntl.h>
#include<unistd.h>
using namespace std;

int main(){
	string s;
	cin>>s;
	s+="FromP1";
	cout<<s<<"\n";
	return 0;
}
