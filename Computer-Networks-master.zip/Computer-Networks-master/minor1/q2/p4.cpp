#include<bits/stdc++.h>
#include<fcntl.h>
#include<unistd.h>
using namespace std;

int main(){
	while(1){
		cout<<"FromP4"<<"\n";
		fflush(stdout);
		sleep(4);
	}
	return 0;
}
