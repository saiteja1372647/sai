#include<bits/stdc++.h>
#include<fcntl.h>
#include<unistd.h>
using namespace std;

int main(){
	while(1){
		string s;
		cin>>s;
		s+="FromP5";
		cout<<s<<"\n";
		fflush(stdout);
	}
	return 0;
}
