#include<bits/stdc++.h>
using namespace std;

int main(){
	cout<<"FromP2";
	return 0;
}
