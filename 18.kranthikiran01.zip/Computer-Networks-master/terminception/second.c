#include <stdio.h>
int main(int argc, char const *argv[])
{
	printf("Hello world from second\n");
	return 0;
}