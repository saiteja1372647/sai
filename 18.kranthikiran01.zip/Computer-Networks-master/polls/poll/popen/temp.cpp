#include<iostream>
using namespace std;
int main()
{
  cout<<"temporary process";
  return 0;
  
}
