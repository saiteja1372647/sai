Virtual character device driver
