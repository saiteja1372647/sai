#include <stdio.h>

int main(){
//char buffer[256];
printf("lol\n");
return 0;
}
