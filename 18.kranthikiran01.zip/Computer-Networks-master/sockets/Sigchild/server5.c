#include <stdio.h>

int main()
{
	printf("In child\n");
	printf("Child terminating\n");
	return 0;
}