#include<unistd.h>
#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>

int main()
{
	
	
	char s[20];
	
	scanf("%s",s);
	printf("Echo back %s",s);
	
	return 0;
	
}
