#include<unistd.h>
#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>
#include<signal.h>

int main()
{
	char s[100];
	printf("Echo Back %s\n",s);	
}
