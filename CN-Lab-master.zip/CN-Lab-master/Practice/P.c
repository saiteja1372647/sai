#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include<netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/poll.h>
#include <stdio.h>  
#include <string.h>   //strlen  
#include <stdlib.h>  
#include <errno.h>  
#include <unistd.h>   //close  
#include <arpa/inet.h>    //close  
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  
#include <sys/time.h>
#include<sys/ioctl.h>

int main()
{
	int out=dup(1);
	int in=dup(1);
	int fd=fileno(popen("./N","w"));
	printf("%d\n",fd);
	dup2(fd,1);
	
	char s[20];
	while(1)
	{
		scanf("%s",s);
		write(fd,s,20);
		fflush(stdout);
	}

}
