#include<stdio.h>

int main()
{
	int a=5;
	int b;
	printf("%d", a);
	scanf("%d", &b);
}
