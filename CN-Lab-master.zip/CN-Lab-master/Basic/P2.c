#include<stdio.h>
#include<unistd.h>

int main()
{
	int d;
	scanf("%d",&d);
	printf("%d", d*d);
	
}
