#include<stdio.h>
#include<unistd.h>
int main()
{
	int d=10;
	printf("%d", d*d);
	
	
}
